package com.greenfoxacademy.springVersion3;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SpringVersion3Application {

	public static void main(String[] args) {
		SpringApplication.run(SpringVersion3Application.class, args);
	}
}
